"use client";
import { useState } from "react";
import { addToCart } from "@/lib/cart";
export default function AddToCart(p: { id: string; name: string; price: number; image: string; soldOut?: boolean }) {
  const [done, setDone] = useState(false);
  if (p.soldOut) return <button className="btn" disabled style={{opacity:.5}}>Sold out</button>;
  return <button className="btn" type="button" onClick={() => { addToCart({ id: p.id, name: p.name, price: p.price, image: p.image }); setDone(true); setTimeout(() => setDone(false), 1500); }}>{done ? "Added ✓" : "Add to cart"}</button>;
}
