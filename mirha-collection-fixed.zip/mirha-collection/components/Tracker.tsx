"use client";
import { useEffect } from "react";
function id(key: string, store: Storage) { let v = store.getItem(key); if (!v) { v = crypto.randomUUID(); store.setItem(key, v); } return v; }
export default function Tracker() {
  useEffect(() => {
    try {
      const q = new URLSearchParams(location.search);
      const body = { visitor_id: id("mc_vid", localStorage), session_id: id("mc_sid", sessionStorage), event_type: "page_view", page_path: location.pathname, referrer: document.referrer || null, utm_source: q.get("utm_source"), utm_medium: q.get("utm_medium"), utm_campaign: q.get("utm_campaign"), utm_term: q.get("utm_term"), device: /Mobi|Android/i.test(navigator.userAgent) ? "mobile" : "desktop" };
      fetch("/api/track", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), keepalive: true }).catch(() => {});
    } catch {}
  }, []);
  return null;
}
