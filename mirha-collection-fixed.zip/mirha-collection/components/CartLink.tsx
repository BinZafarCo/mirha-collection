"use client";
import { useEffect, useState } from "react";
import { readCart } from "@/lib/cart";
export default function CartLink() {
  const [n, setN] = useState(0);
  useEffect(() => { const u = () => setN(readCart().reduce((s, i) => s + i.qty, 0)); u(); window.addEventListener("cart-changed", u); window.addEventListener("storage", u); return () => { window.removeEventListener("cart-changed", u); window.removeEventListener("storage", u); }; }, []);
  return <a href="/checkout">Cart{n ? ` (${n})` : ""}</a>;
}
