"use client";
export type CartItem = { id: string; name: string; price: number; image: string; qty: number };
const KEY = "mirha_cart_v1";
export function readCart(): CartItem[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "[]");
    if (!Array.isArray(raw)) return [];
    return raw.filter((i) => i && typeof i.id === "string" && Number.isInteger(i.qty) && i.qty > 0).slice(0, 50);
  } catch { return []; }
}
export function writeCart(items: CartItem[]) {
  try { localStorage.setItem(KEY, JSON.stringify(items)); window.dispatchEvent(new Event("cart-changed")); } catch {}
}
export function addToCart(item: Omit<CartItem, "qty">) {
  const cart = readCart();
  const found = cart.find((i) => i.id === item.id);
  if (found) found.qty = Math.min(found.qty + 1, 20); else cart.push({ ...item, qty: 1 });
  writeCart(cart);
}
