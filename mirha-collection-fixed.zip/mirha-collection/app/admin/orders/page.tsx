import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { updateOrder } from "./actions";

export const dynamic = "force-dynamic";
const S = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"];
const P = ["pending", "paid", "failed", "refunded"];

export default async function OrdersAdmin({ searchParams }: { searchParams: Promise<{ updated?: string; error?: string }> }) {
  const params = await searchParams;
  const supabase = await createClient();
  if (!supabase) return <main className="admin-wrap"><div className="admin-card"><h1>Orders</h1><p className="muted">Connect Supabase first.</p></div></main>;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/account");
  const { data: staff } = await supabase.from("staff_roles").select("role").eq("user_id", user.id).maybeSingle();
  if (!staff || !["owner", "admin", "manager", "supervisor", "frontdesk"].includes(staff.role)) redirect("/");
  const { data: orders, error } = await supabase.from("orders").select("id,order_number,customer_name,phone,shipping_address,city,payment_method,payment_reference,payment_status,order_status,total,tracking_number,created_at,order_items(product_name,quantity,unit_price)").order("created_at", { ascending: false }).limit(100);
  return <main className="admin-wrap">
    <div className="admin-top"><div><div className="eyebrow">Mirha Collection By BZ</div><h1 className="admin-title">Orders</h1></div><a className="btn" href="/admin">Back to overview</a></div>
    {params.updated && <p className="notice">Order updated.</p>}
    {params.error && <p className="status" role="alert">The order could not be updated.</p>}
    {error && <p className="status">Could not load orders.</p>}
    {!orders?.length && !error && <p className="muted">No orders yet.</p>}
    {(orders ?? []).map((o) => <form key={o.id} action={updateOrder} className="admin-card" style={{ marginBottom: 16 }}>
      <input type="hidden" name="id" value={o.id} />
      <b>{o.order_number}</b> · Rs. {Number(o.total).toLocaleString("en-PK")} · {new Date(o.created_at).toLocaleString("en-PK")}
      <p style={{ margin: "6px 0" }}>{o.customer_name} · {o.phone}<br />{o.shipping_address}, {o.city}<br /><span className="muted">{o.payment_method.toUpperCase()}{o.payment_reference ? ` · TID ${o.payment_reference}` : ""}</span></p>
      <ul className="muted" style={{ margin: "6px 0" }}>{(o.order_items ?? []).map((i, k) => <li key={k}>{i.product_name} × {i.quantity}</li>)}</ul>
      <div className="form-grid compact">
        <label>Order status<select className="field" name="order_status" defaultValue={o.order_status}>{S.map((s) => <option key={s}>{s}</option>)}</select></label>
        <label>Payment<select className="field" name="payment_status" defaultValue={o.payment_status}>{P.map((s) => <option key={s}>{s}</option>)}</select></label>
        <label>Tracking no.<input className="field" name="tracking_number" defaultValue={o.tracking_number ?? ""} maxLength={60} /></label>
      </div><button className="btn small" type="submit">Save</button></form>)}
  </main>;
}
