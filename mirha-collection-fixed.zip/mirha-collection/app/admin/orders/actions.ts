"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const roles = ["owner", "admin", "manager", "supervisor", "frontdesk"];
const orderStatuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"];
const paymentStatuses = ["pending", "paid", "failed", "refunded"];

export async function updateOrder(formData: FormData): Promise<void> {
  const supabase = await createClient();
  if (!supabase) redirect("/account?error=not-configured");
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/account");
  const { data: staff } = await supabase.from("staff_roles").select("role").eq("user_id", user.id).maybeSingle();
  if (!staff || !roles.includes(staff.role)) redirect("/");
  const id = String(formData.get("id") ?? "");
  const order_status = String(formData.get("order_status") ?? "");
  const payment_status = String(formData.get("payment_status") ?? "");
  const tracking = String(formData.get("tracking_number") ?? "").trim().slice(0, 60) || null;
  if (!/^[0-9a-f-]{36}$/i.test(id) || !orderStatuses.includes(order_status) || !paymentStatuses.includes(payment_status)) redirect("/admin/orders?error=invalid");
  const { error } = await supabase.from("orders").update({ order_status, payment_status, tracking_number: tracking }).eq("id", id);
  if (error) redirect("/admin/orders?error=failed");
  revalidatePath("/admin/orders");
  redirect("/admin/orders?updated=1");
}
