"use client";
import { useEffect, useState } from "react";
import { readCart, writeCart, type CartItem } from "@/lib/cart";
import { placeOrder, type OrderResult } from "./actions";

export default function Checkout() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [pay, setPay] = useState("cod");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<OrderResult | null>(null);
  useEffect(() => setCart(readCart()), []);
  const qty = cart.reduce((s, i) => s + i.qty, 0);
  const subtotal = cart.reduce((s, i) => s + i.qty * i.price, 0);
  const shipping = qty ? (qty >= 3 ? 110 : 190) * qty : 0;
  const change = (id: string, d: number) => { const next = cart.map((i) => i.id === id ? { ...i, qty: i.qty + d } : i).filter((i) => i.qty > 0 && i.qty <= 20); setCart(next); writeCart(next); };
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true);
    const f = new FormData(e.currentTarget);
    const r = await placeOrder({ name: String(f.get("name")), phone: String(f.get("phone")), address: String(f.get("address")), city: String(f.get("city")), payment: pay, reference: String(f.get("reference") ?? ""), items: cart.map((i) => ({ id: i.id, qty: i.qty })) });
    setBusy(false); setResult(r);
    if (r.ok) { writeCart([]); setCart([]); }
  }
  if (result?.ok) return <main className="admin-wrap"><div className="admin-card" style={{ maxWidth: 560 }}><div className="eyebrow">Thank you</div><h1>Order placed ✓</h1><p>Your order number is <strong>{result.orderNumber}</strong>.</p><p className="muted">Total payable: Rs. {result.total.toLocaleString("en-PK")} (including Rs. {result.shipping} delivery). We will contact you to confirm.</p><a className="btn" href="/">Continue shopping</a></div></main>;
  return <main className="admin-wrap"><a className="brand" href="/">MIRHA COLLECTION<small>BY BZ</small></a>
    <div className="admin-card" style={{ marginTop: 24, maxWidth: 640 }}><h1>Your cart</h1>
      {!cart.length && <p className="muted">Your cart is empty. <a href="/">Browse the collection</a></p>}
      {cart.map((i) => <div key={i.id} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: "1px solid #eadfe2" }}>
        {i.image && <img src={i.image} alt="" width={56} height={56} style={{ objectFit: "cover", borderRadius: 8 }} />}
        <div style={{ flex: 1 }}><b>{i.name}</b><br /><span className="muted">Rs. {i.price.toLocaleString("en-PK")}</span></div>
        <button className="btn small" type="button" onClick={() => change(i.id, -1)}>−</button><span>{i.qty}</span><button className="btn small" type="button" onClick={() => change(i.id, 1)}>+</button></div>)}
      {!!cart.length && <>
        <p>Subtotal: Rs. {subtotal.toLocaleString("en-PK")}<br />Delivery: Rs. {shipping} <span className="muted">(Rs. 110 per piece for 3+ pieces, otherwise Rs. 190)</span><br /><b>Total: Rs. {(subtotal + shipping).toLocaleString("en-PK")}</b></p>
        <form onSubmit={submit}>
          <input className="field" name="name" placeholder="Full name" required maxLength={120} />
          <input className="field" name="phone" placeholder="Mobile (03001234567)" inputMode="tel" required />
          <input className="field" name="city" placeholder="City" required maxLength={80} />
          <input className="field" name="address" placeholder="Full delivery address" required maxLength={400} />
          <select className="field" value={pay} onChange={(e) => setPay(e.target.value)}><option value="cod">Cash on Delivery</option><option value="jazzcash">JazzCash</option><option value="easypaisa">EasyPaisa</option></select>
          {pay !== "cod" && <input className="field" name="reference" placeholder="Payment transaction ID (TID)" required minLength={6} maxLength={60} />}
          {result && !result.ok && <p className="status" role="alert">{result.error}</p>}
          <button className="btn" type="submit" disabled={busy}>{busy ? "Placing order…" : "Place order"}</button>
        </form><p className="muted">Prices are confirmed securely by our server. We never ask for card numbers or PINs.</p></>}
    </div></main>;
}
