"use server";
import { createClient } from "@/lib/supabase/server";

export type OrderResult = { ok: true; orderNumber: string; total: number; shipping: number } | { ok: false; error: string };
type Input = { name: string; phone: string; address: string; city: string; payment: string; reference: string; items: { id: string; qty: number }[] };

export async function placeOrder(input: Input): Promise<OrderResult> {
  const name = String(input.name ?? "").trim().slice(0, 120);
  const phone = String(input.phone ?? "").replace(/[^\d+]/g, "").slice(0, 16);
  const address = String(input.address ?? "").trim().slice(0, 400);
  const city = String(input.city ?? "").trim().slice(0, 80);
  const payment = String(input.payment ?? "");
  const reference = String(input.reference ?? "").trim().slice(0, 60);
  if (!name || !address || !city) return { ok: false, error: "Please fill in name, address and city." };
  if (!/^(\+92|0)3\d{9}$/.test(phone)) return { ok: false, error: "Enter a valid Pakistani mobile number, e.g. 03001234567." };
  if (!["cod", "jazzcash", "easypaisa"].includes(payment)) return { ok: false, error: "Choose a payment method." };
  if (payment !== "cod" && reference.length < 6) return { ok: false, error: "Enter the transaction ID (TID) of your payment." };
  const items = (Array.isArray(input.items) ? input.items : []).slice(0, 50).map((i) => ({ product_id: String(i.id), quantity: Number(i.qty) })).filter((i) => /^[0-9a-f-]{36}$/i.test(i.product_id) && Number.isInteger(i.quantity) && i.quantity > 0 && i.quantity <= 20);
  if (!items.length) return { ok: false, error: "Your cart is empty." };
  const supabase = await createClient();
  if (!supabase) return { ok: false, error: "Ordering is temporarily unavailable." };
  const { data, error } = await supabase.rpc("place_order", { p_customer_name: name, p_phone: phone, p_shipping_address: address, p_city: city, p_payment_method: payment, p_payment_reference: payment === "cod" ? "" : reference, p_items: items });
  if (error) {
    const known = ["Not enough stock", "no longer available", "Too many orders", "Cart is empty"];
    return { ok: false, error: known.some((k) => error.message.includes(k)) ? error.message : "We could not place your order. Please try again." };
  }
  const r = data as { order_number: string; total: number; shipping_fee: number };
  return { ok: true, orderNumber: r.order_number, total: Number(r.total), shipping: Number(r.shipping_fee) };
}
