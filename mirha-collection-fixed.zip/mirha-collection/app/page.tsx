import { createClient } from "@/lib/supabase/server";
import AddToCart from "@/components/AddToCart";
import CartLink from "@/components/CartLink";
import Tracker from "@/components/Tracker";

export const dynamic = "force-dynamic";
const wa = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");

export default async function Home({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const { category } = await searchParams;
  const supabase = await createClient();
  let products: { id: string; name: string; category: string; price: number; compare: number | null; image: string; stock: number }[] = [];
  let categories: string[] = [];
  if (supabase) {
    const { data } = await supabase.from("products").select("id,name,category,price,compare_at_price,cover_url,stock").eq("status", "active").order("created_at", { ascending: false }).limit(100);
    const all = (data ?? []).map((p) => ({ id: p.id as string, name: p.name as string, category: (p.category as string) || "Collection", price: Number(p.price), compare: p.compare_at_price ? Number(p.compare_at_price) : null, image: (p.cover_url as string) ?? "", stock: Number(p.stock) }));
    categories = [...new Set(all.map((p) => p.category))];
    products = category ? all.filter((p) => p.category === category) : all;
  }
  return <>
    <Tracker />
    <div className="topline">CASH ON DELIVERY AVAILABLE ACROSS PAKISTAN</div>
    <header className="header"><a className="brand" href="/">MIRHA COLLECTION<small>BY BZ</small></a>
      <nav className="nav"><a href="#collection">Shop</a>{wa && <a href={`https://wa.me/${wa}`} target="_blank" rel="noreferrer">WhatsApp</a>}<a href="/account">Account</a><CartLink /></nav></header>
    <main>
      <section className="hero"><div className="hero-copy"><div className="eyebrow">A considered collection</div><h1>Style that feels<br />like you.</h1><p>Thoughtfully selected pieces for everyday elegance, celebrations and every season.</p><a className="btn light" href="#collection">Discover the collection</a></div></section>
      <section className="section" id="collection">
        <div className="section-head"><span>Curated for you</span><h2>The Collection</h2></div>
        <div className="categories"><a className={"chip" + (!category ? " active" : "")} href="/#collection">All</a>{categories.map((c) => <a key={c} className={"chip" + (category === c ? " active" : "")} href={`/?category=${encodeURIComponent(c)}#collection`}>{c}</a>)}</div>
        {!products.length && <p className="muted">{supabase ? "New pieces are coming soon. Please check back shortly." : "Store is being set up."}</p>}
        <div className="products">{products.map((p) => <article className="product" key={p.id}>
          <div className="product-media">{p.image ? <img src={p.image} alt={p.name} loading="lazy" /> : <span className="muted">Image coming soon</span>}</div>
          <div className="product-info"><div className="product-cat">{p.category}</div><h3>{p.name}</h3>
            <div className="price">Rs. {p.price.toLocaleString("en-PK")} {p.compare && p.compare > p.price && <s className="muted" style={{fontSize:13}}>Rs. {p.compare.toLocaleString("en-PK")}</s>}</div>
            <AddToCart id={p.id} name={p.name} price={p.price} image={p.image} soldOut={p.stock <= 0} />
          </div></article>)}</div>
      </section>
    </main>
    <footer className="footer"><div><div className="brand" style={{ color: "#fff" }}>MIRHA COLLECTION<small>BY BZ</small></div><p>Thoughtful fashion and personal service. Serving customers across Pakistan.</p></div>
      <div><strong>Customer care</strong><p>{wa ? "WhatsApp support" : "Order support"}<br />Cash on Delivery<br />JazzCash &amp; EasyPaisa</p></div>
      <div><strong>Information</strong><p><a href="/account">Customer account</a></p></div>
      <small>© {new Date().getFullYear()} Mirha Collection By BZ. All rights reserved.</small></footer>
  </>;
}
