import { getCloudflareContext } from "@opennextjs/cloudflare";
type D1Like = { prepare(sql: string): { bind(...v: unknown[]): unknown }; batch(stmts: unknown[]): Promise<unknown> };
const s = (v: unknown, max = 300) => (typeof v === "string" && v.trim() ? v.trim().slice(0, max) : null);
const uuid = /^[0-9a-f-]{36}$/i;
export async function POST(req: Request) {
  try {
    const b = await req.json();
    const vid = s(b.visitor_id, 40), sid = s(b.session_id, 40);
    if (!vid || !sid || !uuid.test(vid) || !uuid.test(sid)) return new Response(null, { status: 204 });
    const { env } = await getCloudflareContext({ async: true });
    const db = (env as { DB?: D1Like }).DB;
    if (!db) return new Response(null, { status: 204 });
    const cf = (req as Request & { cf?: { country?: string; city?: string } }).cf;
    await db.batch([
      db.prepare("INSERT INTO visitors (id, first_source, first_medium, first_campaign, first_referrer, landing_page, country, city, device) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9) ON CONFLICT(id) DO UPDATE SET last_seen=datetime('now')")
        .bind(vid, s(b.utm_source, 80), s(b.utm_medium, 80), s(b.utm_campaign, 120), s(b.referrer), s(b.page_path), cf?.country ?? null, cf?.city ?? null, s(b.device, 20)),
      db.prepare("INSERT INTO visitor_events (visitor_id, session_id, event_type, page_path, referrer, utm_source, utm_medium, utm_campaign, utm_term) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9)")
        .bind(vid, sid, s(b.event_type, 40) ?? "page_view", s(b.page_path), s(b.referrer), s(b.utm_source, 80), s(b.utm_medium, 80), s(b.utm_campaign, 120), s(b.utm_term, 120)),
    ]);
  } catch {}
  return new Response(null, { status: 204 });
}
