-- Final state of checkout logic already applied to the live project (idempotent).
create sequence if not exists public.order_number_seq start 1001;

create or replace function public.place_order(
  p_customer_name text, p_phone text, p_shipping_address text, p_city text,
  p_payment_method text, p_payment_reference text, p_items jsonb)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_uid uuid := auth.uid(); v_customer_id uuid; v_order_id uuid; v_order_number text;
  v_subtotal numeric := 0; v_shipping numeric := 0; v_qty int := 0; v_item record; v_prod record;
begin
  if coalesce(trim(p_customer_name), '') = '' then raise exception 'Name is required'; end if;
  if coalesce(trim(p_phone), '') = '' then raise exception 'Phone is required'; end if;
  if coalesce(trim(p_shipping_address), '') = '' then raise exception 'Address is required'; end if;
  if p_payment_method not in ('cod','jazzcash','easypaisa','bank') then raise exception 'Invalid payment method'; end if;
  if (select count(*) from public.orders where phone = trim(p_phone) and created_at > now() - interval '1 hour') >= 3 then
    raise exception 'Too many orders from this phone number. Please call us to place more.'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'Cart is empty'; end if;
  for v_item in select (i->>'product_id')::uuid as product_id, sum((i->>'quantity')::int) as qty
    from jsonb_array_elements(p_items) i group by 1 order by 1 loop
    if v_item.qty is null or v_item.qty <= 0 or v_item.qty > 100 then raise exception 'Invalid quantity'; end if;
    select * into v_prod from public.products where id = v_item.product_id and status = 'active' for update;
    if not found then raise exception 'A product in your cart is no longer available'; end if;
    if v_prod.stock < v_item.qty then raise exception 'Not enough stock for %', v_prod.name; end if;
    v_subtotal := v_subtotal + v_prod.price * v_item.qty; v_qty := v_qty + v_item.qty;
  end loop;
  v_shipping := (case when v_qty >= 3 then 110 else 190 end) * v_qty;
  if v_uid is not null and exists (select 1 from public.customers where id = v_uid) then v_customer_id := v_uid; end if;
  v_order_number := 'MC-' || to_char(now() at time zone 'Asia/Karachi', 'YYMMDD') || '-' || nextval('public.order_number_seq');
  insert into public.orders (order_number, customer_id, customer_name, phone, shipping_address, city, payment_method, payment_reference, subtotal, shipping_fee, total)
  values (v_order_number, v_customer_id, trim(p_customer_name), trim(p_phone), trim(p_shipping_address), nullif(trim(p_city), ''), p_payment_method, nullif(trim(p_payment_reference), ''), v_subtotal, v_shipping, v_subtotal + v_shipping)
  returning id into v_order_id;
  for v_item in select (i->>'product_id')::uuid as product_id, sum((i->>'quantity')::int) as qty
    from jsonb_array_elements(p_items) i group by 1 order by 1 loop
    select * into v_prod from public.products where id = v_item.product_id;
    insert into public.order_items (order_id, product_id, product_name, sku, quantity, unit_price) values (v_order_id, v_prod.id, v_prod.name, v_prod.sku, v_item.qty, v_prod.price);
    update public.products set stock = stock - v_item.qty, updated_at = now() where id = v_prod.id;
    insert into public.inventory_movements (product_id, quantity_delta, reason) values (v_prod.id, -v_item.qty, 'order ' || v_order_number);
  end loop;
  return jsonb_build_object('order_id', v_order_id, 'order_number', v_order_number, 'shipping_fee', v_shipping, 'total', v_subtotal + v_shipping);
end; $$;
revoke all on function public.place_order(text,text,text,text,text,text,jsonb) from public;
grant execute on function public.place_order(text,text,text,text,text,text,jsonb) to anon, authenticated;
